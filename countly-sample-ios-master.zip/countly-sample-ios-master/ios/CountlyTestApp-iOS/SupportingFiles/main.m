//
// main.m
//
// This code is provided under the MIT License.
//
// Please visit www.count.ly for more information.


#import <UIKit/UIKit.h>

#import "AppDelegate.h"
#import "EYLogViewer.h"

int main(int argc, char * argv[])
{
//    [EYLogViewer add]; //Use this to see logs on device

    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
