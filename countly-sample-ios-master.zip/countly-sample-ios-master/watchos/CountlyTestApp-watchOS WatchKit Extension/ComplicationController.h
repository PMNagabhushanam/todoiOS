// ComplicationController.h
//
// This code is provided under the MIT License.
//
// Please visit www.count.ly for more information.

#import <ClockKit/ClockKit.h>

@interface ComplicationController : NSObject <CLKComplicationDataSource>

@end
