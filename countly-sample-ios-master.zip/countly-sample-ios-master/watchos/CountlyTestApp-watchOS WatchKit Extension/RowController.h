// RowController.h
//
// This code is provided under the MIT License.
//
// Please visit www.count.ly for more information.

#import <Foundation/Foundation.h>
#import <WatchKit/WatchKit.h>

@interface RowController : NSObject
@property (weak, nonatomic) IBOutlet WKInterfaceLabel* label;
@end
