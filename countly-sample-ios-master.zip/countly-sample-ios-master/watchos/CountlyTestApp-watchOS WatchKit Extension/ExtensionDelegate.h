// ExtensionDelegate.h
//
// This code is provided under the MIT License.
//
// Please visit www.count.ly for more information.

#import <WatchKit/WatchKit.h>

@interface ExtensionDelegate : NSObject <WKExtensionDelegate>

@end
