//  CountlyTestApp-iOS-swift-Bridging-Header.h
//
// This code is provided under the MIT License.
//
// Please visit www.count.ly for more information.


#ifndef CountlyTestApp_iOS_swift_Bridging_Header_h
#define CountlyTestApp_iOS_swift_Bridging_Header_h

#import "Countly.h"

#endif /* CountlyTestApp_iOS_swift_Bridging_Header_h */
